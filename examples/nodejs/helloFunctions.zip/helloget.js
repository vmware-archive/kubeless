module.exports = {
  foo: function (req, res) {
    res.end('hello world')
  }
}
