module.exports = {
  foo: function (event, context) {
    return 'hello world!';
  }
}
