'use strict';

module.exports = {
  handler: (context) => {
    console.log(context);
  }
};
